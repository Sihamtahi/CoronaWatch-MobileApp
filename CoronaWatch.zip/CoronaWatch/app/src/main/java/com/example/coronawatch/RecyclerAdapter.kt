package com.example.coronawatch

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.fragment_facebook.view.*


class RecyclerAdapter : RecyclerView.Adapter<RecyclerAdapter.ViewHolder>() {

    private val names = arrayOf("يوبا دوايدي", "يوبا دوايدي", "يوبا دوايدي")

    private val date_pub = arrayOf("8 نوفمبر", "8 نوفمبر", "8 نوفمبر")

    private val nbLike = arrayOf("256", "256", "256")

    private val nbComment = arrayOf("24", "24", "24")

    private val contenu_pub = arrayOf(" تسجيل 119 حالة جديدة مصابة بفيروس كورونا المستجد", " تسجيل 119 حالة جديدة مصابة بفيروس كورونا المستجد",
        " تسجيل 119 حالة جديدة مصابة بفيروس كورونا المستجد ")

    private val images_avatar = intArrayOf(R.mipmap.avatar,
        R.mipmap.avatar,R.mipmap.avatar)

    private val images_pub = intArrayOf(R.mipmap.img,
        R.mipmap.img,R.mipmap.img)

    private val images_likes = intArrayOf(R.mipmap.path,
        R.mipmap.path,R.mipmap.path)

    private val images_comments = intArrayOf(R.mipmap.com,
        R.mipmap.com,R.mipmap.com)

    private val images_share = intArrayOf(R.mipmap.share,
        R.mipmap.share,R.mipmap.share)

    private val images_supp = intArrayOf(R.mipmap.inf,
        R.mipmap.inf,R.mipmap.inf)


    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        var shareImage: ImageView
        var likeImage: ImageView
        var commentImage: ImageView
        var hideImage: ImageView
        var avatarImage: ImageView
        var pubImage: ImageView
        var name: TextView
        var time: TextView
        var contenu: TextView
        var nb_like: TextView
        var nb_comm: TextView

        init {
            shareImage = itemView.findViewById(R.id.share)
            likeImage = itemView.findViewById(R.id.like)
            commentImage = itemView.findViewById(R.id.comment)
            hideImage = itemView.findViewById(R.id.hide)
            avatarImage = itemView.findViewById(R.id.avatar)
            pubImage =  itemView.findViewById(R.id.pub_img)
            name =  itemView.findViewById(R.id.name)
            time =  itemView.findViewById(R.id.time)
            contenu =  itemView.findViewById(R.id.text_pub)
            nb_like =  itemView.findViewById(R.id.nb_like)
            nb_comm =  itemView.findViewById(R.id.nb_comm)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(viewGroup.context)
            .inflate(R.layout.fragment_facebook, viewGroup, false)
        return ViewHolder(v)
    }
    override fun onBindViewHolder(viewHolder: ViewHolder, i: Int) {
        viewHolder.nb_comm.text = nbComment[i]
        viewHolder.nb_like.text = nbLike[i]
        viewHolder.contenu.text = contenu_pub[i]
        viewHolder.time.text = date_pub[i]
        viewHolder.name.text = names[i]
        viewHolder.shareImage.setImageResource(images_share[i])
        viewHolder.pubImage.setImageResource(images_pub[i])
        viewHolder.likeImage.setImageResource(images_likes[i])
        viewHolder.commentImage.setImageResource(images_comments[i])
        viewHolder.hideImage.setImageResource(images_supp[i])
        viewHolder.avatarImage.setImageResource(images_avatar[i])
    }
    override fun getItemCount(): Int {
        return names.size
    }
}